

<!DOCTYPE html>


<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="{{asset('mart/assets/images/favicon.png')}}">
    <title>Lasnami Amine </title>
    <!-- Custom CSS -->
    <meta name="csrf-token" content="{{ csrf_token() }}" />

    <link href="{{asset('mart/assets/extra-libs/c3/c3.min.css')}}" rel="stylesheet">
    <link href="{{asset('mart/assets/libs/chartist/dist/chartist.min.css')}}" rel="stylesheet">
    <link href="{{asset('mart/assets/extra-libs/jvector/jquery-jvectormap-2.0.2.css')}}" rel="stylesheet" />
    <!-- Custom CSS -->
    <link href="{{asset('mart/dist/css/style.min.css')}}" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet" />

    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <link href="{{asset('css/toastr.css')}}" rel="stylesheet">
    <style>
           
                .modal-body{
                    height: 50vh;
                    overflow-y: auto;
                }

    </style>


</head>

<body>
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper" data-theme="light" data-layout="vertical" data-navbarbg="skin6" data-sidebartype="full"
        data-sidebar-position="fixed" data-header-position="fixed" data-boxed-layout="full">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <header class="topbar" data-navbarbg="skin6">
            <nav class="navbar top-navbar navbar-expand-md">
                <div class="navbar-header" data-logobg="skin6">
                    <a class="nav-toggler waves-effect waves-light d-block d-md-none" href="javascript:void(0)"><i
                            class="ti-menu ti-close"></i></a>
                    <div class="navbar-brand">
                        <a href="index.html">
                            Home
                        </a>
                    </div>
                    <a class="topbartoggler d-block d-md-none waves-effect waves-light" href="javascript:void(0)"
                        data-toggle="collapse" data-target="#navbarSupportedContent"
                        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><i
                            class="ti-more"></i></a>
                </div>
                <div class="navbar-collapse collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav float-left mr-auto ml-3 pl-1">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle pl-md-3 position-relative" href="javascript:void(0)"
                                id="bell" role="button" data-toggle="dropdown" aria-haspopup="true"
                                aria-expanded="false">
                                <span><i data-feather="bell" class="svg-icon"></i></span>
                                <span class="badge badge-primary notify-no rounded-circle">5</span>
                            </a>
                        </li>
                    </ul>
                    <ul class="navbar-nav float-right">
                        <li class="nav-item d-none d-md-block">
                            <a class="nav-link" href="javascript:void(0)">
                                <form>
                                    <div class="customize-input">
                                        <input class="form-control custom-shadow custom-radius border-0 bg-white"
                                            type="search" placeholder="Search" aria-label="Search">
                                        <i class="form-control-icon" data-feather="search"></i>
                                    </div>
                                </form>
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>
        </header>
        <!-- ============================================================== -->
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <aside class="left-sidebar" data-sidebarbg="skin6">
            <div class="scroll-sidebar" data-sidebarbg="skin6">
                <nav class="sidebar-nav">
                    <ul id="sidebarnav">
                        <li class="sidebar-item"> 
                            <a class="sidebar-link sidebar-link" href="{{route('home')}}" aria-expanded="false">
                                <i data-feather="home" class="feather-icon"></i>
                                <span class="hide-menu">Tableau de bord</span>
                            </a>
                        </li>

                        <li class="sidebar-item"> 
                            <a class="sidebar-link sidebar-link" href="{{route('client.index')}}" aria-expanded="false">
                                <i data-feather="home" class="feather-icon"></i>
                                <span class="hide-menu">Clients</span>
                            </a>
                        </li>

                        <li class="sidebar-item"> 
                            <a class="sidebar-link sidebar-link" href="{{route('traduction.index')}}" aria-expanded="false">
                                <i data-feather="home" class="feather-icon"></i>
                                <span class="hide-menu">Traduction</span>
                            </a>
                        </li>
                        


                        <li class="sidebar-item"> 
                            <a class="sidebar-link sidebar-link" href="/papiers" aria-expanded="false">
                                <i data-feather="home" class="feather-icon"></i>
                                <span class="hide-menu">Mes Documents</span>
                            </a>
                        </li>



                        
                        <li class="sidebar-item"> <a class="sidebar-link" href="{{route('wilaya.fournisseurs')}}"
                                aria-expanded="false"><i data-feather="tag" class="feather-icon"></i>
                                <span
                                    class="hide-menu">Paramètres
                                </span></a>
                        </li>

      
                        <li class="sidebar-item"> <a class="sidebar-link" 
                        href="{{ route('logout') }}" 
                        onclick="event.preventDefault();document.getElementById('logout-form').submit();"
                        aria-expanded="false"><i data-feather="tag" class="feather-icon"></i>
                                <span
                                    class="hide-menu">déconnexion 
                                </span></a>
                            <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                @csrf
                            </form>

                        </li>


                    </ul>
                </nav>
            </div>
        </aside>
        <div class="page-wrapper">
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-7 align-self-center">
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb m-0 p-0">
                                    <li class="breadcrumb-item"><a href="index.html">Tableau de bord</a>
                                    </li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container-fluid">
                @yield('content')
            </div>
            <footer class="footer text-center text-muted">
            </footer>
        </div>
</div>

<div class="modal fade "  id="squarespaceModal" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true" >
                <div class="modal-dialog modal-lg" >
                    <div class="modal-content">
                        <div class="modal-header">
                            <h3 class="modal-title" id="lineModalLabel">Ajouter client</h3>
                        </div>

                            <div class="modal-body">

                                    <form action="{{route('client.create')}}" method="post" enctype="multipart/form-data">
                                            @csrf


                                            <div class="form-group">
                                                <label for="exampleInputEmail1">nom  : </label>

                                                <input type="text" class="form-control"  value="{{ old('name') }}" name="name" id="nom" placeholder="votre nom ">

                                            </div>

                                            <div class="form-group">

                                                <label for="exampleInputEmail1">prenom  : </label>

                                                <input type="text" class="form-control"  value="{{ old('prenom') }}" name="prenom" id="prenom" placeholder="votre prenom ">

                                              </div>

                                        



                                            <div class="form-group">

                                                <label for="exampleInputEmail1">N Téléphone :</label>

                                                <input type="text" value="{{ old('telephone') }}" name="telephone" class="form-control" id="" placeholder="Enter votre numero de téléphone ">

                                            </div>


                            

                                            <div class="btn-group" role="group">

                                                    <button type="submit" class="btn btn-primary">Save</button>
                                                    <button type="button" class="btn btn-danger" data-dismiss="modal"  role="button">Fermer</button>

                                                </div>
                                            

                                     </form>



                            </div>

        </div>
      </div>
     </div> 


    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="{{asset('mart/assets/libs/jquery/dist/jquery.min.js')}}"></script>
    <script src="{{asset('mart/assets/libs/popper.js/dist/umd/popper.min.js')}}"></script>
    <script src="{{asset('mart/assets/libs/bootstrap/dist/js/bootstrap.min.js')}}"></script>
    <!-- apps -->
    <!-- apps -->
    <script src="{{asset('mart/dist/js/app-style-switcher.js')}}"></script>
    <script src="{{asset('mart/dist/js/feather.min.js')}}"></script>
    <script src="{{asset('mart/assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js')}}"></script>
    <script src="{{asset('mart/dist/js/sidebarmenu.js')}}"></script>
    <!--Custom JavaScript -->
    <script src="{{asset('mart/dist/js/custom.min.js')}}"></script>
    <script src="{{asset('js/dynamic-form.js')}}"></script>

    <script src="{{asset('js/toastr.min.js')}}"></script>

    <!--This page JavaScript -->
    <script src="{{asset('mart/assets/extra-libs/c3/d3.min.js')}}"></script>
    <script src="{{asset('mart/assets/extra-libs/c3/c3.min.js')}}"></script>
    <script src="{{asset('mart/assets/libs/chartist/dist/chartist.min.js')}}"></script>
    <script src="{{asset('mart/assets/libs/chartist-plugin-tooltips/dist/chartist-plugin-tooltip.min.js')}}"></script>
    <script src="{{asset('mart/assets/extra-libs/jvector/jquery-jvectormap-2.0.2.min.js')}}"></script>
    <script src="{{asset('mart/assets/extra-libs/jvector/jquery-jvectormap-world-mill-en.js')}}"></script>
    <script src="{{asset('mart/dist/js/pages/dashboards/dashboard1.min.js')}}"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js" crossorigin="anonymous"></script>
  <script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js" crossorigin="anonymous"></script>

    <script src="{{asset('js/datatables-demo.js')}}"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>

    <script>
$(document).ready(function() {
    $('.js-example-basic-single').select2();
});
  @if(session('success'))
      $(function(){
          toastr.success('{{Session::get("success")}}')
      })
  @endif
  @if ($errors->any())
      $(function(){
        @foreach ($errors->all() as $error)
                  toastr.error('{{$error}}')
        @endforeach
      })
  @endif
  @if(session('error'))
    $(function(){
        toastr.error('{{Session::get("error")}}')
    })
  @endif

$('.affiche_livreurs').on('change', function (e) {
    var optionSelected = $("option:selected", this);
    var valueSelected = this.value;
    var lien = "/livreur/filter/"+valueSelected;
    $('#filter_livreur').attr('href',lien)
});

// setInterval(function(){

//   $('#ad-modal').modal('show');
// }, 30000); //This value is represented in mili seconds.


</script>

  @yield('scripts')

</body>

</html>