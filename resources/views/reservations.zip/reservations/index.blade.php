@extends('layouts.master')

@section('content')
<?php 
$stade1=0;
$stade2=0;
$total=0;

$stade3=0;
foreach($reservations as $reservation){
    $total+=$reservation->prix;
    if($reservation->stade=="1"){
        $stade1=$stade1+$reservation->prix;
    }
    if($reservation->stade=="2"){
        $stade2=$stade2+$reservation->prix;        
    }
    if($reservation->stade=="3"){
        $stade3=$stade3+$reservation->prix;        
    }

}

?>
                                <div class="container-fluid">
                                    <div class="card mb-4">
                                        <h2>
                                            Liste de tous les reservations
                                        </h2>

                                        <div class="card-header">
                                            <form method="post" action="{{route('reservation.filter')}}">                                                    
                                                @csrf
                                                <div class="row">
                                                    <div class="col-md-2" >
                                                        <label class="control-label">{{ __('Début') }}: </label>
                                                        <input class="form-control" value="{{$date_debut ?? ''}}" name="date_debut" type="date" />
                                                    </div>

                                                    <div class="col-md-2" >
                                                        <label class="control-label">{{ __('Fin') }}: </label>
                                                        <input class="form-control" value="{{$date_fin ?? ''}}" name="date_fin" type="date" />
                                                    </div>
                                                    <div class="col-md-2" style="padding:35px;">
                                                        <button type="submit" class="row btn btn-primary" >
                                                            Filtrer
                                                    </button>                                                                                                        
                                            </div>
                                        </form>
                                    </div>
                                    @if(Auth::guard('admin')->user()['is_super'] == 1)
                                        <div class="card-group">                
                                            <div class="card border-right">
                                                <div class="card-body">
                                                    <div class="d-flex d-lg-flex d-md-block align-items-center">
                                                        <div>
                                                        <h2 style="text-align: center;  "><b>Total 1 </b></h2>                                                            
                                                            <h2 class="text-dark mb-1 w-100 text-truncate font-weight-medium">{{$total ?? ''}} DA</h2>
                                                            </h6>                                                            
                                                        </div>
                                                    </div>
                                                </div> 
                                            </div>
                                            <div class="card border-right">
                                                <div class="card-body">
                                                    <div class="d-flex d-lg-flex d-md-block align-items-center">
                                                        <div>
                                                        <h2 style="text-align: center;  "><b>Recette pour stade 1 </b></h2>                                                            
                                                            <h2 class="text-dark mb-1 w-100 text-truncate font-weight-medium">{{$stade1 ?? ''}} DA</h2>
                                                            </h6>                                                            
                                                        </div>
                                                    </div>
                                                </div> 
                                            </div>

                                            <div class="card border-right">
                                                <div class="card-body">
                                                    <div class="d-flex d-lg-flex d-md-block align-items-center">
                                                        <div>
                                                        <h2 style="text-align: center;  "><b>Recette pour stade 2</b></h2>
                                                            <div class="d-inline-flex align-items-center">
                                                                <h2 style="text-align: center;  " class="text-dark mb-1 font-weight-medium">{{$stade2 ?? ''}} DA</h2>
                                                            </div>
                                                        </div>                                                        
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="card">
                                                <div class="card-body">
                                                    <div class="d-flex d-lg-flex d-md-block align-items-center">
                                                        <div>
                                                        <h2 style="text-align: center;  "><b>Recette pour stade 3</b></h2>
                                                            <h2 class="text-dark mb-1 font-weight-medium">{{$stade3 ?? ''}} DA</h2>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        @endif

                            </div>

 

                            <div class="card-body">
                                <div class="table-responsive">
                                <table class="table table-bordered"  width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th>fullname</th>
                                                <th>phone</th>                                                
                                                <th>type</th>
                                                <th>stade</th>
                                                <th>prix</th>
                                                <th>crenau</th>
                                                <th>date</th>

                                                <th>actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach($reservations as $reservation)          
                                                @if($reservation->abonnement == null)
                                                    <tr>

                                                        <td>
                                                        {{$reservation->fullname }}
                                                        <br>
                                                        @if($reservation->state ==1)
                                                        <span class="badge badge-success"> payé  </span>
                                                        @else
                                                        <span class="badge badge-danger"> non payé  </span>
                                                        @endif                                                 
                                                        </td>
                                                        <td> {{$reservation->phone }} </td>
                                                        <td> @if($reservation->abonnement != null) <span class="badge badge-warning">abonnement </span> @else resrvation simple @endif
                                                        </td>
                                                        <td> {{$reservation->stade }} </td>
                                                        <td> <span class="badge badge-info"> {{$reservation->prix }} DA </span> </td>
                                                        <td> {{$reservation->crenau }} H </td>
                                                        <td> {{$reservation->date }} </td>
                                                        <td >
                                                            <div class="table-action">  

                                                                    <a class="btn btn-info text-white" data-toggle="modal" data-target="#editres{{$reservation->id}}">
                                                                        modifier
                                                                    </a>


                                                                <div class="dropdown">



                                                                <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton{{$reservation->id}}" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                    Actions
                                                                </button>
                                                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton{{$reservation->id}}">
                                                                    <a href="{{route('reservation.destroy',['reservation'=>$reservation->id])}}"
                                                                        class="dropdown-item"
                                                                        onclick="return confirm('Are you sure?')"
                                                                        >
                                                                        Delete
                                                                    </a>

                                                                </div>
                                                                </div>
                                                            </div>


                                                        </td>
                                                        
                                                    </tr>
                                                    @include('includes.edit_res',['reservation' => $reservation])

                                                @endif                                 
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
            @endsection
@section('scripts')
<script>
function watchWilayaChanges() {
            $('#wilaya_select').on('change', function (e) {
                e.preventDefault();
                var $communes = $('#commune_select');
                var $communesLoader = $('#commune_select_loading');
                var $iconLoader = $communes.parents('.input-group').find('.loader-spinner');
                var $iconDefault = $communes.parents('.input-group').find('.material-icons');
                $communes.hide().prop('disabled', 'disabled').find('option').not(':first').remove();
                $communesLoader.show();
                $iconDefault.hide();
                $iconLoader.show();
                $.ajax({
                    dataType: "json",
                    method: "GET",
                    url: "/api/static/communes/ " + $(this).val()
                })
                    .done(function (response) {
                        $.each(response, function (key, commune) {
                            $communes.append($('<option>', {value: commune.id}).text(commune.name));
                        });
                        $communes.prop('disabled', '').show();
                        $communesLoader.hide();
                        $iconLoader.hide();
                        $iconDefault.show();
                    });
            });
        }

        $(document).ready(function () {
            watchWilayaChanges();
            $('.regler').on('click', function(event){
                var id = this.id;
                $('#formregler').attr('action','/traduction/regler/'+id)
            })


        });
        
        /**
         * 
         */
</script>

@endsection